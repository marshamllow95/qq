#!/bin/sh

curl -s wttr.in/karlsruhe\?format=1
