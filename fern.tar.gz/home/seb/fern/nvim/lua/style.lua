local styles = {
	none = "none",
	underline = "underline",
	undercurl = "undercurl",
	reverse = "reverse",
	inverse = "inverse",
	italic = "italic",
	standout = "standout",
}

return styles
