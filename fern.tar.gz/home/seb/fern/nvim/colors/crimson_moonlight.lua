require("boo-colorscheme").use({ theme = "crimson_moonlight" })
