require("boo-colorscheme").use({ theme = "forest_stream" })
