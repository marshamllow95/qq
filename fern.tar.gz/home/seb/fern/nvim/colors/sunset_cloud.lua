require("boo-colorscheme").use({ theme = "sunset_cloud" })
