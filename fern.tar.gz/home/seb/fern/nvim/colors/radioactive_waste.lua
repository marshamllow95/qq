require("boo-colorscheme").use({ theme = "radioactive_waste" })
